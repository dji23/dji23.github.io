$(document).ready(function(){

	"use strict";

	/* =================================
	LOADER 
	=================================== */
	$("#owl-slide").owlCarousel({
 
		autoPlay : 5000,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination : false,
		singleItem:true,
		transitionStyle : "fade"
 
  });
	
	
	
	
});




  
  